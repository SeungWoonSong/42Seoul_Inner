Hi!

I'm Pawe� and I like to draw pixels - here's my contribution to the open and friendly world we live in!

It is a full game kit to prototype or make a full game!
There is a possibility of making some small free updates to this kit. If you have any ideas, leave a comment. If you like this asset, please rate it! :)

You can use it free of charge for any commercial or non-commercial project.
Credits are not required, but really appreciated!
If you would like to, you can leave me a tip ;)

Best Regards,
Pawe� Jarosz